REPLACE INTO wp_options (option_name, option_value, autoload) VALUES ('e2etest', '200', 'no');
